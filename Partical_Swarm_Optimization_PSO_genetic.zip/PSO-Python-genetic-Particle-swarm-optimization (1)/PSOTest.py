import random
import time

## python PSOTest.py  <no_of_particles> <iterations> <inertia> <xVelocityCoeff> <yVelocityCoeff> <xMax> <yMax> <xMin> <yMin>
#	python PSOTest.py 10 10 0.5 0.8 0.9 4.5 4.5 -4.5 -4.5
import sys
value=random.random()


print("PSO test Start");

# v(k+1)=w.v(k)+c1.rand1.(pbest-x) +c2.rand2.(gbest-x)
# update position as x(k+1) =x(k) +v(k+1)
#w = inertia
#c1 = x vaelocity coeff
#c2 = y velocity coeff
# rand1,2 = 0<=rand<=1

def NewVelocity(z,Inertia,xVelocityCoeff,yVelocityCoeff,global_best_fitness):
	x=float(z[0])
	y=float(z[1])
	temp=[2]
	#pString="(global_best_fitness[1]:"+str(global_best_fitness)
	#print(pString)
	z[0]=(Inertia)*(x) + (xVelocityCoeff)*(random.random())*((global_best_fitness[1])-(x)) + yVelocityCoeff*random.random()*(global_best_fitness[1]-x)
	z[1]=Inertia*y + yVelocityCoeff*random.random()*(global_best_fitness[2]-y) + yVelocityCoeff*random.random()*(global_best_fitness[2]-y)
	#print(x,y)
	return z
	

def FindGbest(A,global_best_fitness,myfile):
	if global_best_fitness[0]>A[2]:
		global_best_fitness[0]=A[2]
		pString1="New global best found:"+str(A[2])
		print(pString1)
		global_best_fitness[1]=A[0]
		global_best_fitness[2]=A[1]
		pString2="New global best Co-Ordinates found:"+str(global_best_fitness[1])+","+str(global_best_fitness[2])
		pString=pString1+","+pString2+"\n"
		print(pString2)
		myfile.write(pString)
	else:
		print("New Global best not found on this iteration")
	return global_best_fitness
	
	
	
def printMatrix(x):
	for i in x:
		print (i)
		#for j in i:
		#	print(j)

def pointsAfterDec(x):
    s = str(x)
    if not '.' in s:
        return 0
    return len(s) - s.index('.') - 1
	

	
	
def FitnessFunction(mat):
	#xyzArray=[0,0,0,float('inf')]
	x=mat[0]
	y=mat[1]
	# xyzArray[0]=mat[0]
	# xyzArray[1]=mat[1]
	mat[2]=(1.5-x+x*y)**2 + (2.25-x+x*y**2)**2 +(2.625-x+x*y**3)**2
	if mat[3]>mat[2] :
		mat[3]=mat[2]
	return mat

def RandomAllocation(no_of_particles,xMax,yMax,xMin,yMin,value):
	#xyarray=no_of_particles*[2*[0]]
	xyarray=[0,0,0,0]
	#print (xyarray)
	random.seed(value)
	xMplen=pointsAfterDec(xMax)
	if xMplen>0 :
		xMax=xMax*(10*xMplen)
	yMplen=pointsAfterDec(yMax)
	if yMplen>0 :
		yMax=yMax*(10*yMplen)
	xNplen=pointsAfterDec(xMin)
	if xNplen>0 :
		xMin=xMin*(10*xNplen)
	yNplen=pointsAfterDec(yMin)
	if yNplen>0 :
		yMin=yMin*(10*yNplen)
	print(xMplen,yMplen,xNplen,yNplen)
	value=value+random.random() 
#for i in range(no_of_particles):
		#box=[]
		#box.append(round((((float)(random.randrange(xMin,xMax)))/(10*xMplen)),1))
		#box.append(round((((float)(random.randrange(yMin,yMax)))/(10*yNplen)),1))
		#xyarray[i][0]=random.randrange(xMin,xMax)
		#xyarray[i][1]=random.randrange(yMin,yMax)
	random.seed(value*i+no_of_particles)
	#xyarray[i][0]=(round((((float)(random.randrange(xMin,xMax,int((random.random()/i)))))/(10*xMplen)),1))
	xyarray[0]=((((float)(random.randrange(xMin,xMax)))/(10*xMplen)))
	random.seed(value*i+no_of_particles+5000)
	#xyarray[i][1]=(round((((float)(random.randrange(yMin,yMax,int((random.random()/i)))))/(10*yNplen)),1))
	xyarray[1]=((((float)(random.randrange(yMin,yMax)))/(10*yNplen)))
	random.seed(value*i+no_of_particles+5760)
	xyarray[2]=0
	xyarray[3]=float('inf')
		#xyarray.append(box)
	value=value+random.random()+value*i+no_of_particles
	return xyarray


FullArray=[]
global_best_fitness=[float('inf'), float('inf'),float('inf')]
global_best_pos=[float('inf'), float('inf')]
for x in range (-45,45):
	#print (x/10.0)
	x=x/10.0
	#f(x,y)=(1.5-x+xy)^2+(2.25-x+xy^2)^2
	y=1.5
	z=((1.5-x+x*y)**2+(2.25-x+x*y**2)**2)
	#print ((1.5-x+x*y)**2+(2.25-x+x*y**2)**2)
	FullArray.append([x,y,z])
#print(FullArray)
print(FullArray[1][2])
# for i in FullArray:
	# print(i)
	
	
	
print(' ')
no_of_particles=int(sys.argv[1])
printString="No of Item particles is :\t"+str(no_of_particles)
print(printString)

iterations=int(sys.argv[2])
printString="No of Iterations is :\t"+str(iterations)
print(printString)

Inertia=float(sys.argv[3])
printString="Inertia Value is :\t"+str(Inertia)
print(printString)

xVelocityCoeff=float(sys.argv[4])
printString="xVelocityCoeff Value is :\t"+str(xVelocityCoeff)
print(printString)

yVelocityCoeff=float(sys.argv[5])
printString="yVelocityCoeff Value is :\t"+str(yVelocityCoeff)
print(printString)

xMax=float(sys.argv[6])
printString="xMax Value is :\t"+str(xMax)
print(printString)

yMax=float(sys.argv[7])
printString="yMax Value is :\t"+str(yMax)
print(printString)

xMin=float(sys.argv[8])
printString="xMin Value is :\t"+str(xMin)
print(printString)

yMin=float(sys.argv[9])
printString="yMin Value is :\t"+str(yMin)
print(printString)
print(' ')








xycoordinates=[]
# xycoordinates=RandomAllocation(no_of_particles,xMax,yMax,xMin,yMin,value)
# printMatrix(xycoordinates)
# return for below function is a three dimensional array with values xCo-Ordinate yCo-Ordinate within range
for i in range(no_of_particles):
	xycoordinates.append(RandomAllocation(no_of_particles,xMax,yMax,xMin,yMin,value))
print(" ")
print("X, Y coordinates")
print(xycoordinates)
print(" ")
print("X, Y coordinates")
printMatrix(xycoordinates)
fitnessCalc=[]
timestr = time.strftime("%Y%m%d-%H%M%S")
print timestr
filenm="IndividualRun"+timestr+".csv"
myfile=open(filenm, "w")
for i in xycoordinates:
	fitnessCalc.append(FitnessFunction(i))


for Ai in range(iterations) :

	print(" ")
	print("X, Y , Z co ordinates before finding pbest")
	printMatrix(fitnessCalc)
	print(" ")
	print("X, Y , Z co ordinates After finding pbest")
	DummyArray=[]
	for i in fitnessCalc:
		DummyArray.append(FitnessFunction(i))
		
	fitnessCalc=DummyArray
	printMatrix(fitnessCalc)
	
	print(" ")
	print("co ordinates With gbest")
	DummyArray=[]
	for i in fitnessCalc:
		global_best_fitness=(FindGbest(i,global_best_fitness,myfile))
	#	DummyArray.append(FindGbest(i,global_best_fitness))
	#global_best_fitness=DummyArray
	##Calc velcoity and new dimension value for x,y
	DummyArray=[]
	for i in fitnessCalc:
		DummyArray.append(NewVelocity(i,Inertia,xVelocityCoeff,yVelocityCoeff,global_best_fitness))
	fitnessCalc=DummyArray
x=3.0
y=0.5
pString="Exact gbest  for the fucntion analyzed((1.5-x+x*y)**2 + (2.25-x+x*y**2)**2 +(2.625-x+x*y**3)**2) (Beale function) is  : "+ str((1.5-x+x*y)**2 + (2.25-x+x*y**2)**2 +(2.625-x+x*y**3)**2) +" With Co-Ordinates:"+ str(x)+ ","+ str(y)
print(pString)		
pString= str(iterations) +", iterations complete, the Global best value identified is : ,"+ str(global_best_fitness[0]) +" , With Co-Ordinates:,"+ str(global_best_fitness[1])+ ","+ str(global_best_fitness[2])+"\n"
print(pString)
with open("AllRunsStats.csv", "a") as myfile:
    myfile.write(pString)


#psuedocode
#Random allocation algorithm
##	for each particle in system 
# for dimension x and y
# initialize positions x|y (p) within the range given 
# initialize velocity of each particle withing permissible range

#Fitness value calculation
##	for each particle
	# calculate dimension z as fitness value
		# if fitness value is better than p_best value in history --> set current valuie as pbest
	#choose the particle having best among the hole group as g_best particle
		
#Update position and caluculate velocity
##	for each particle 
		# for each dimension
			# calculate velocity according to below
				# v(k+1)=w.v(k)+c1.rand1.(pbest-x) +c2.rand2.(gbest-x)
				# update position as x(k+1) =x(k) +v(k+1)

#w = inertia
#c1 = x vaelocity coeff
#c2 = y velocity coeff
# rand1,2 = 0<=rand<=1


				
				